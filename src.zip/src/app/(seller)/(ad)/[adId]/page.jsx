import Image from "next/image";

export default function ViewAd() {
  return <div>ViewAd</div>;
}
