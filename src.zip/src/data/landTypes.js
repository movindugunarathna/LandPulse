export const landTypes = [
    { type: "Agricultural", value: 1 },
    { type: "Commercial", value: 2 },
    { type: "Residential", value: 3 },
    { type: "Other", value: 4 },
];
