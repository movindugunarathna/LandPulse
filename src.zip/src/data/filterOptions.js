export const filterOptions = {
    "Latest posts": 1,
    "Price low to high": 2,
    "Price high to low": 3,
    "Perch low to high": 4,
    "Perch high to low": 5,
    "Predicted price posts": 6,
};
